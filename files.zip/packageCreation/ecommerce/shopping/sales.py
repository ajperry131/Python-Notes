def calc_tax():
    pass


def calc_sales():
    pass
